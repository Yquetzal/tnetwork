# tnetwork - temporal networks library

tnetwork is a simple library to manipulate temporal networks and dynamic communities
## Installation

To install the latest (develoopment) version of the library, use:

```bash
pip install --upgrade git+https://github.com/Yquetzal/tnetwork.git
```

to install the latest stable version, you can use:
```bash
pip install --upgrade tnetwork
```

## Documentation
The documentation is available here:
https://tnetwork.readthedocs.io/en/latest/

## Collaborate with us!

``tnetwork`` is an active project, any contribution is welcome!

