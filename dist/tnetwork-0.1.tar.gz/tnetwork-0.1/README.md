# tnetwork - temporal networks library

tnetwork is a simple library to manipulate temporal networks and dynamic communities
## Installation

To install the library, use pip:

```bash
pip install git+https://github.com/Yquetzal/tnetwork.git
```


## Documentation
The documentation is available here:
https://tnetwork.readthedocs.io/en/latest/

## Collaborate with us!

``tnetwork`` is an active project, any contribution is welcome!

