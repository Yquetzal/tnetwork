# tnetwork - temporal networks library

tnetwork is a simple library to manipulate temporal networks, and dynamic snapshots on these networks.
## Installation

To install the library just download (or clone) the current project and copy the tnetwork folder in the root of your application.

Alternatively use pip:
```bash
pip install git+https://github.com/Yquetzal/tnetwork.git
```

## Collaborate with us!

``tnetwork`` is an active project, any contribution is welcome!

