from tnetwork.dyn_graph.dyn_graph_ig import DynGraphIG
from tnetwork.dyn_graph.function import *
from tnetwork.dyn_graph.dyn_graph_sn import DynGraphSN