from tnetwork.dyn_graph.dyn_graph_sg import DynGraphSG
from tnetwork.dyn_graph.function import *
from tnetwork.dyn_graph.dyn_graph_sn import DynGraphSN